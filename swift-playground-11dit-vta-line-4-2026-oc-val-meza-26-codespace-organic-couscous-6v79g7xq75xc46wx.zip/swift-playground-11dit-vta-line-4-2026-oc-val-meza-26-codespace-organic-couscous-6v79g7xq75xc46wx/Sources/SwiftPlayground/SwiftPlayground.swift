// The Swift Programming Language
// https://docs.swift.org/swift-book

@main
struct SwiftPlayground {
        static func main() {
                print("Welcome to Screen Time Tracker.")

                //asks the user for the hour limit

                print("What is the hour limit set for each day?")
                print("enter a number:")
                var hourLimit = Int(readLine()!)!
                //if it is more or less than 0-24, let the user retry
                while hourLimit > 25 || hourLimit < -1 {
                        print("enter a number between 0-24")
                        hourLimit = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Monday
                print("On Monday how many hours did you spend on:")
                print("Twitter:")
                var twitterMonday = Int(readLine()!)!
                print("Reddit:")
                var redditMonday = Int(readLine()!)!
                print("Discord:")
                var discordMonday = Int(readLine()!)!
                print("Instagram:")
                var instagramMonday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatMonday = Int(readLine()!)!
                //tells the total hours of Monday
                let totalHoursMonday =
                        (twitterMonday + redditMonday + discordMonday + instagramMonday
                                + snapchatMonday)
                print("Overall on Monday you spent \(totalHoursMonday) hours doomscrolling")

                //if the total hours exceed 24, let the user try again as that is impossible
                if totalHoursMonday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Monday how many hours did you spend on:")
                        print("Twitter:")
                        twitterMonday = Int(readLine()!)!
                        print("Reddit:")
                        redditMonday = Int(readLine()!)!
                        print("Discord:")
                        discordMonday = Int(readLine()!)!
                        print("Instagram:")
                        instagramMonday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatMonday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Tuesday
                print("On Tuesday how many hours did you spend on:")
                print("Twitter:")
                var twitterTuesday = Int(readLine()!)!
                print("Reddit:")
                var redditTuesday = Int(readLine()!)!
                print("Discord:")
                var discordTuesday = Int(readLine()!)!
                print("Instagram:")
                var instagramTuesday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatTuesday = Int(readLine()!)!
                //tells the total hours of Tuesday
                let totalHoursTuesday =
                        (twitterTuesday + redditTuesday + discordTuesday + instagramTuesday
                                + snapchatTuesday)
                print("Overall on Tuesday you spent \(totalHoursTuesday) hours doomscrolling")

                //if the total hours exceed 24, let the user try again as that is impossible
                if totalHoursTuesday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Tuesday how many hours did you spend on:")
                        print("Twitter:")
                        twitterTuesday = Int(readLine()!)!
                        print("Reddit:")
                        redditTuesday = Int(readLine()!)!
                        print("Discord:")
                        discordTuesday = Int(readLine()!)!
                        print("Instagram:")
                        instagramTuesday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatTuesday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Wednesday
                print("On Wednesday how many hours did you spend on:")
                print("Twitter:")
                var twitterWednesday = Int(readLine()!)!
                print("Reddit:")
                var redditWednesday = Int(readLine()!)!
                print("Discord:")
                var discordWednesday = Int(readLine()!)!
                print("Instagram:")
                var instagramWednesday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatWednesday = Int(readLine()!)!
                //tells the total hours of Wedsnesday
                let totalHoursWednesday =
                        (twitterWednesday + redditWednesday + discordWednesday
                                + instagramWednesday + snapchatWednesday)
                print("Overall on Wednesday you spent \(totalHoursWednesday) hours doomscrolling")

                //if the total hours exceed 24, let the user try again as that is impossible
                if totalHoursWednesday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Wednesday how many hours did you spend on:")
                        print("Twitter:")
                        twitterWednesday = Int(readLine()!)!
                        print("Reddit:")
                        redditWednesday = Int(readLine()!)!
                        print("Discord:")
                        discordWednesday = Int(readLine()!)!
                        print("Instagram:")
                        instagramWednesday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatWednesday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Thursday
                print("On Thursday how many hours did you spend on:")
                print("Twitter:")
                var twitterThursday = Int(readLine()!)!
                print("Reddit:")
                var redditThursday = Int(readLine()!)!
                print("Discord:")
                var discordThursday = Int(readLine()!)!
                print("Instagram:")
                var instagramThursday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatThursday = Int(readLine()!)!
                //tells the total hours of Thursday
                let totalHoursThursday =
                        (twitterThursday + redditThursday + discordThursday
                                + instagramThursday + snapchatThursday)
                print("Overall on Thursday you spent \(totalHoursThursday) hours doomscrolling")

                if totalHoursThursday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Thursday how many hours did you spend on:")
                        print("Twitter:")
                        twitterThursday = Int(readLine()!)!
                        print("Reddit:")
                        redditThursday = Int(readLine()!)!
                        print("Discord:")
                        discordThursday = Int(readLine()!)!
                        print("Instagram:")
                        instagramThursday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatThursday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Friday
                print("On Friday how many hours did you spend on:")
                print("Twitter:")
                var twitterFriday = Int(readLine()!)!
                print("Reddit:")
                var redditFriday = Int(readLine()!)!
                print("Discord:")
                var discordFriday = Int(readLine()!)!
                print("Instagram:")
                var instagramFriday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatFriday = Int(readLine()!)!
                //tells the total hours of Friday
                let totalHoursFriday =
                        (twitterFriday + redditFriday + discordFriday + instagramFriday
                                + snapchatFriday)
                print("Overall on Friday you spent \(totalHoursFriday) hours doomscrolling")

                if totalHoursFriday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Friday how many hours did you spend on:")
                        print("Twitter:")
                        twitterFriday = Int(readLine()!)!
                        print("Reddit:")
                        redditFriday = Int(readLine()!)!
                        print("Discord:")
                        discordFriday = Int(readLine()!)!
                        print("Instagram:")
                        instagramFriday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatFriday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Saturday
                print("On Saturday how many hours did you spend on:")
                print("Twitter:")
                var twitterSaturday = Int(readLine()!)!
                print("Reddit:")
                var redditSaturday = Int(readLine()!)!
                print("Discord:")
                var discordSaturday = Int(readLine()!)!
                print("Instagram:")
                var instagramSaturday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatSaturday = Int(readLine()!)!
                //tells the total hours of Saturday
                let totalHoursSaturday =
                        (twitterSaturday + redditSaturday + discordSaturday
                                + instagramSaturday + snapchatSaturday)
                print("Overall on Saturday you spent \(totalHoursSaturday) hours doomscrolling")

                if totalHoursSaturday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Saturday how many hours did you spend on:")
                        print("Twitter:")
                        twitterSaturday = Int(readLine()!)!
                        print("Reddit:")
                        redditSaturday = Int(readLine()!)!
                        print("Discord:")
                        discordSaturday = Int(readLine()!)!
                        print("Instagram:")
                        instagramSaturday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatSaturday = Int(readLine()!)!
                }

                //asks them for how many hours they spent on each app on Sunday
                print("On Sunday how many hours did you spend on:")
                print("Twitter:")
                var twitterSunday = Int(readLine()!)!
                print("Reddit:")
                var redditSunday = Int(readLine()!)!
                print("Discord:")
                var discordSunday = Int(readLine()!)!
                print("Instagram:")
                var instagramSunday = Int(readLine()!)!
                print("Snapchat:")
                var snapchatSunday = Int(readLine()!)!
                //tells the total hours of Sunday
                let totalHoursSunday =
                        (twitterSunday + redditSunday + discordSunday + instagramSunday
                                + snapchatSunday)
                print("Overall on Sunday you spent \(totalHoursSunday) hours doomscrolling")

                if totalHoursSunday >= 25 {
                        print("total hours are over 24 hours. try again")
                        print("On Sunday how many hours did you spend on:")
                        print("Twitter:")
                        twitterSunday = Int(readLine()!)!
                        print("Reddit:")
                        redditSunday = Int(readLine()!)!
                        print("Discord:")
                        discordSunday = Int(readLine()!)!
                        print("Instagram:")
                        instagramSunday = Int(readLine()!)!
                        print("Snapchat:")
                        snapchatSunday = Int(readLine()!)!
                }

                //summary of total hours spent
                let totalHoursWeek =
                        (totalHoursMonday + totalHoursTuesday + totalHoursWednesday
                                + totalHoursWednesday + totalHoursThursday
                                + totalHoursFriday + totalHoursSaturday + totalHoursSunday)
                print("-This week you spent \(totalHoursWeek) hours doom scrolling.")
                let averageWeekHours = (totalHoursWeek / 7)
                print("-Average of \(averageWeekHours) hours per day")

                //if the average hours are more than the limit
                if averageWeekHours > hourLimit {
                        print("Overall, your usage is OVER the limit!")
                        //if the avergage hours are less or equal to the limit
                } else {
                        print("Overall, your usage is UNDER the limit, congrats!")
                }
        }

}
